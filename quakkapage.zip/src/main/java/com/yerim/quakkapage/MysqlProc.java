package com.yerim.quakkapage;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class MysqlProc {
	
	static public String TABLE_BOARD = "quakka_board";
	static public int BOARD_LIST_AMOUT = 5;
	static private Connection con = null;
	static private Statement st = null;
	
	static public void initDb() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		}catch(ClassNotFoundException e){
			e.printStackTrace();
		}
	}

	
	static public void connectDb() {
		try {
			con =  DriverManager.getConnection("jdbc:mysql://localhost:3306/quakkalover", "root", "admin");
			st = con.createStatement();
			System.out.println("====DB connected");
		
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	static public ResultSet exeQuery(String sql) {
		try {
			return st.executeQuery(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return null;
	}
	
	static public int exeUpdate(String sql) {
		try {
			return st.executeUpdate(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		} 
		return -100;
		
	}
	
	static public void disconnectDb() {
		try {
			if(st!=null) {
				st.close();
			}
			if(con!=null) {
				con.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	

	static public int getDataCount() {
		connectDb();
		ResultSet re = exeQuery("select count(*) from "+TABLE_BOARD);
		
		try {
			re.next();
			int count = Integer.parseInt(re.getString("count(*)"));
			disconnectDb();
			return count;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		disconnectDb();
		return 0;
	}
	
	
}



